CREATE PROCEDURE sayhelloworld
AS
BEGIN
    DBMS_OUTPUT.put_line ('hello world');
END;
/

